celery --app=sna.celery:app worker --loglevel=INFO
